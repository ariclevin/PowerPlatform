var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./PCFNaicsCodeSplitter/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./PCFNaicsCodeSplitter/index.ts":
/*!***************************************!*\
  !*** ./PCFNaicsCodeSplitter/index.ts ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar PCFNaicsCodeSplitter =\n/** @class */\nfunction () {\n  function PCFNaicsCodeSplitter() {}\n\n  PCFNaicsCodeSplitter.prototype.init = function (context, notifyOutputChanged, state, container) {\n    // Add control initialization code\n    this._context = context;\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._container = container;\n    this._naicsCodeChanged = this.naicsCodeChanged.bind(this); // textbox control\n\n    this._naicsCodeElement = document.createElement(\"input\");\n\n    this._naicsCodeElement.setAttribute(\"type\", \"text\");\n\n    this._naicsCodeElement.setAttribute(\"placeholder\", \"Enter a 6 Digit NAICS Code\");\n\n    this._naicsCodeElement.setAttribute(\"class\", \"pcfinputcontrol\");\n\n    this._naicsCodeElement.addEventListener(\"change\", this._naicsCodeChanged);\n\n    this._naicsCodeErrorElement = document.createElement(\"div\");\n\n    this._naicsCodeErrorElement.setAttribute(\"class\", \"pcferrorcontroldiv\");\n\n    var naicsErrorChild1 = document.createElement(\"label\");\n    naicsErrorChild1.setAttribute(\"class\", \"pcferrorcontrolimage\");\n    naicsErrorChild1.innerText = \"\";\n    var naicsErrorChild2 = document.createElement(\"label\");\n    naicsErrorChild2.setAttribute(\"id\", \"errorelementlabelid\");\n    naicsErrorChild2.setAttribute(\"class\", \"pcferrorcontrollabel\");\n    naicsErrorChild2.innerText = \"Invalid NAICS Code Entered\";\n\n    this._naicsCodeErrorElement.appendChild(naicsErrorChild1);\n\n    this._naicsCodeErrorElement.appendChild(naicsErrorChild2);\n\n    this._naicsCodeErrorElement.style.display = \"none\";\n\n    this._container.appendChild(this._naicsCodeElement);\n\n    this._container.appendChild(this._naicsCodeErrorElement);\n\n    this._naics2FieldName = context.parameters.NAICS2Control.raw;\n    this._naics4FieldName = context.parameters.NAICS4Control.raw;\n    this._naics6FieldName = context.parameters.NAICS6Control.raw;\n    this._naics2FieldName != null ? console.log(this._naics2FieldName) : console.log(\"Naics2FieldName is Null\");\n    this._naics4FieldName != null ? console.log(this._naics4FieldName) : console.log(\"Naics4FieldName is Null\");\n    this._naics6FieldName != null ? console.log(this._naics6FieldName) : console.log(\"Naics6FieldName is Null\");\n  };\n\n  PCFNaicsCodeSplitter.prototype.updateView = function (context) {\n    // Add code to update control view\n    // Display Error\n    if (this._naicsCodeErrorElement.style.display != \"none\") {\n      var message = \"The NAICS COde  is not valid.\";\n      var type = \"ERROR\"; //INFO, WARNING, ERROR\n\n      var id = \"9443\"; //Notification Id\n\n      var time = 5000; //Display time in milliseconds\n      // @ts-ignore \n\n      Xrm.Page.ui.setFormNotification(message, type, id); //Wait the designated time and then remove the notification\n\n      setTimeout(function () {\n        // @ts-ignore \n        Xrm.Page.ui.clearFormNotification(id);\n      }, time);\n    }\n  };\n\n  PCFNaicsCodeSplitter.prototype.RetrieveNAICSReferences = function (naicsCode) {\n    debugger;\n    var entityName = \"cdsp_naics6title\";\n    var retrieveMultipleOptions = \"?$select=_cdsp_naics2_value,_cdsp_naics4_value,cdsp_naics6titleid,cdsp_title&$filter=cdsp_number eq '\" + naicsCode + \"'\"; // var retrieveMultipleOptions = \"?$select=cdsp_naics6titleid,cdsp_title&$filter=cdsp_code eq '\" + naicsCode + \"'\";\n\n    var thisRef = this;\n\n    this._context.webAPI.retrieveMultipleRecords(entityName, retrieveMultipleOptions).then(function (results) {\n      for (var _i = 0, _a = results.entities; _i < _a.length; _i++) {\n        var entity = _a[_i];\n        var naics2Value = entity[\"_cdsp_naics2_value\"];\n        var naics2Text = entity[\"_cdsp_naics2_value@OData.Community.Display.V1.FormattedValue\"];\n        var naics4Value = entity[\"_cdsp_naics4_value\"];\n        var naics4Text = entity[\"_cdsp_naics4_value@OData.Community.Display.V1.FormattedValue\"];\n        var naics6Value = entity[\"cdsp_naics6titleid\"];\n        var naics6Text = entity[\"cdsp_title\"];\n        console.log(naics2Value);\n        console.log(naics2Text);\n        console.log(naics4Value);\n        console.log(naics4Text);\n        console.log(naics6Value);\n        console.log(naics6Text); // @ts-ignore\n\n        Xrm.Page.getAttribute(thisRef._naics2FieldName).setValue([{\n          id: naics2Value,\n          name: naics2Text,\n          entityType: \"cdsp_naics2industry\"\n        }]); // @ts-ignore\n\n        Xrm.Page.getAttribute(thisRef._naics4FieldName).setValue([{\n          id: naics4Value,\n          name: naics4Text,\n          entityType: \"cdsp_naics4subsector\"\n        }]); // @ts-ignore\n\n        Xrm.Page.getAttribute(thisRef._naics6FieldName).setValue([{\n          id: naics6Value,\n          name: naics6Text,\n          entityType: \"cdsp_naics6title\"\n        }]);\n        break;\n      }\n    }, function (error) {\n      thisRef._context.navigation.openAlertDialog(error.message);\n\n      return [];\n    });\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  PCFNaicsCodeSplitter.prototype.getOutputs = function () {\n    return {\n      NAICSCode: this._naics6id\n    };\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  PCFNaicsCodeSplitter.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n    this._naicsCodeElement.removeEventListener(\"change\", this._naicsCodeChanged);\n  };\n\n  PCFNaicsCodeSplitter.prototype.naicsCodeChanged = function (evt) {\n    var naicsCode = this._naicsCodeElement.value;\n    console.log(naicsCode);\n    this.RetrieveNAICSReferences(naicsCode);\n\n    this._notifyOutputChanged();\n  };\n\n  return PCFNaicsCodeSplitter;\n}();\n\nexports.PCFNaicsCodeSplitter = PCFNaicsCodeSplitter;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./PCFNaicsCodeSplitter/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('PCFControls.PCFNaicsCodeSplitter', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PCFNaicsCodeSplitter);
} else {
	var PCFControls = PCFControls || {};
	PCFControls.PCFNaicsCodeSplitter = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PCFNaicsCodeSplitter;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}