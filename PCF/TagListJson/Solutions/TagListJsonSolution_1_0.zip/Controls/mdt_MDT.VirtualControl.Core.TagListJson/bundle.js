/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./TagListJson/JSONList.tsx":
/*!**********************************!*\
  !*** ./TagListJson/JSONList.tsx ***!
  \**********************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

eval("\n\nvar __extends = this && this.__extends || function () {\n  var _extendStatics = function extendStatics(d, b) {\n    _extendStatics = Object.setPrototypeOf || {\n      __proto__: []\n    } instanceof Array && function (d, b) {\n      d.__proto__ = b;\n    } || function (d, b) {\n      for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];\n    };\n    return _extendStatics(d, b);\n  };\n  return function (d, b) {\n    if (typeof b !== \"function\" && b !== null) throw new TypeError(\"Class extends value \" + String(b) + \" is not a constructor or null\");\n    _extendStatics(d, b);\n    function __() {\n      this.constructor = d;\n    }\n    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());\n  };\n}();\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.JSONList = void 0;\nvar React = __webpack_require__(/*! react */ \"react\");\nvar JSONList = /** @class */function (_super) {\n  __extends(JSONList, _super);\n  function JSONList(props) {\n    var _this = _super.call(this, props) || this;\n    _this.loadJSON = function () {\n      var data = _this.formatJson(_this.state.json);\n      data = Object.assign({}, JSON.parse(data));\n      _this.renderJson(data);\n    };\n    _this.items = new Array();\n    _this.state = {\n      title: _this.props.title,\n      json: _this.props.json,\n      items: _this.items\n    };\n    _this.loadJSON();\n    return _this;\n  }\n  JSONList.prototype.render = function () {\n    return React.createElement(\"div\", {\n      className: \"tagListContainer\"\n    }, this.state.items);\n  };\n  JSONList.prototype.renderJson = function (jsonData) {\n    var _this = this;\n    Object.keys(jsonData).forEach(function (key) {\n      var value = jsonData[key];\n      if (typeof value == \"object\" && value instanceof Array) {\n        var title = key;\n        value.forEach(function (item) {\n          _this.items.push(React.createElement(\"span\", {\n            className: item.color\n          }, item.output));\n        });\n      }\n    });\n    this.setState({\n      items: this.items\n    });\n  };\n  JSONList.prototype.formatJson = function (json) {\n    if (json) {\n      if (json.startsWith(\"[\") && json.endsWith(\"]\")) return \"{\\\"\\\":\" + json + \"}\";else return json;\n    } else return \"{ \\\"\\\": \\\"\\\" }\";\n  };\n  return JSONList;\n}(React.Component);\nexports.JSONList = JSONList;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./TagListJson/JSONList.tsx?");

/***/ }),

/***/ "./TagListJson/index.ts":
/*!******************************!*\
  !*** ./TagListJson/index.ts ***!
  \******************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.TagListJson = void 0;\nvar JSONList_1 = __webpack_require__(/*! ./JSONList */ \"./TagListJson/JSONList.tsx\");\nvar React = __webpack_require__(/*! react */ \"react\");\nvar TagListJson = /** @class */function () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function TagListJson() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   */\n  TagListJson.prototype.init = function (context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n    this._json = context.parameters.jsonAttribute.raw;\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   * @returns ReactElement root react element for the control\r\n   */\n  TagListJson.prototype.updateView = function (context) {\n    return React.createElement(JSONList_1.JSONList, {\n      title: 'JSON Tags',\n      json: this._json\n    });\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  TagListJson.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  TagListJson.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n  };\n  return TagListJson;\n}();\nexports.TagListJson = TagListJson;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./TagListJson/index.ts?");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/***/ ((module) => {

module.exports = React;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./TagListJson/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('MDT.VirtualControl.Core.TagListJson', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.TagListJson);
} else {
	var MDT = MDT || {};
	MDT.VirtualControl = MDT.VirtualControl || {};
	MDT.VirtualControl.Core = MDT.VirtualControl.Core || {};
	MDT.VirtualControl.Core.TagListJson = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.TagListJson;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}