/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./NotificationList/NotificationList.tsx":
/*!***********************************************!*\
  !*** ./NotificationList/NotificationList.tsx ***!
  \***********************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

eval("\n\nvar __extends = this && this.__extends || function () {\n  var _extendStatics = function extendStatics(d, b) {\n    _extendStatics = Object.setPrototypeOf || {\n      __proto__: []\n    } instanceof Array && function (d, b) {\n      d.__proto__ = b;\n    } || function (d, b) {\n      for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];\n    };\n    return _extendStatics(d, b);\n  };\n  return function (d, b) {\n    if (typeof b !== \"function\" && b !== null) throw new TypeError(\"Class extends value \" + String(b) + \" is not a constructor or null\");\n    _extendStatics(d, b);\n    function __() {\n      this.constructor = d;\n    }\n    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());\n  };\n}();\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.NotificationListControl = void 0;\nvar React = __webpack_require__(/*! react */ \"react\");\nvar react_1 = __webpack_require__(/*! @fluentui/react */ \"@fluentui/react\");\nvar react_2 = __webpack_require__(/*! @fluentui/react */ \"@fluentui/react\");\nvar react_3 = __webpack_require__(/*! @fluentui/react */ \"@fluentui/react\");\nvar Styling_1 = __webpack_require__(/*! @fluentui/react/lib/Styling */ \"@fluentui/react\");\n// Styles definition\nvar stackStyles = {\n  root: {\n    background: Styling_1.DefaultPalette.neutralLight,\n    // height: 200,\n    width: \"100%\"\n  }\n};\nvar stackItemStyles = {\n  root: {\n    alignItems: 'left',\n    background: Styling_1.DefaultPalette.neutralLighter,\n    color: Styling_1.DefaultPalette.blueDark,\n    // display: 'flex',\n    justifyContent: 'left'\n  }\n};\nvar stackItemActionStyles = {\n  root: {\n    alignItems: 'right',\n    background: Styling_1.DefaultPalette.neutralLight,\n    color: Styling_1.DefaultPalette.blueDark,\n    justifyContent: 'right',\n    borderBottom: 1,\n    height: 25\n  }\n};\n// Tokens definition\nvar outerStackTokens = {\n  childrenGap: 5\n};\nvar innerStackTokens = {\n  childrenGap: 5,\n  padding: 10\n};\nvar itemAlignmentsStackTokens = {\n  childrenGap: 5,\n  padding: 10\n};\nvar OpenIcon = {\n  iconName: 'OpenInNewTab'\n};\nvar SendIcon = {\n  iconName: 'Send'\n};\nvar HideIcon = {\n  iconName: 'Hide'\n};\nvar ActionIcon = {\n  iconName: 'SetAction'\n};\nvar menuProps = {\n  items: [{\n    key: 'edit',\n    text: 'Open Notification',\n    iconProps: {\n      iconName: 'OpenInNewTab'\n    }\n  }, {\n    key: 'resentNotification',\n    text: 'Resend Notifcation',\n    iconProps: {\n      iconName: 'Send'\n    }\n  }, {\n    key: 'hideNotification',\n    text: 'Hide Notification',\n    iconProps: {\n      iconName: 'Hide'\n    }\n  }],\n  directionalHintFixed: true\n};\nvar calloutProps = {\n  gapSpace: 0\n};\nvar hostStyles = {\n  root: {\n    display: 'inline-block'\n  }\n};\nvar NotificationListControl = /** @class */function (_super) {\n  __extends(NotificationListControl, _super);\n  function NotificationListControl() {\n    return _super !== null && _super.apply(this, arguments) || this;\n  }\n  NotificationListControl.prototype.render = function () {\n    var _this = this;\n    var ds = this.props.dataset;\n    var notifications = [];\n    ds.sortedRecordIds.forEach(function (item) {\n      notifications.push({\n        notificationId: ds.records[item].getRecordId(),\n        notificationTitle: ds.records[item].getFormattedValue(_this.props.publisherPrefix + \"title\"),\n        notificationBody: ds.records[item].getFormattedValue(_this.props.publisherPrefix + \"body\"),\n        notificationCategory: ds.records[item].getFormattedValue(_this.props.publisherPrefix + \"regardingid\"),\n        notificationDate: ds.records[item].getFormattedValue(\"createdon\")\n      });\n    });\n    return React.createElement(react_1.Stack, {\n      tokens: outerStackTokens,\n      className: \"fullWidth\"\n    }, notifications.map(function (item) {\n      return React.createElement(react_1.Stack, {\n        verticalAlign: 'stretch',\n        key: item.notificationId,\n        styles: stackStyles,\n        tokens: innerStackTokens\n      }, React.createElement(react_1.Stack.Item, {\n        align: 'stretch',\n        key: item.notificationId,\n        styles: stackItemStyles\n      }, React.createElement(\"div\", {\n        className: \"notificationHeader\"\n      }, React.createElement(\"div\", {\n        className: \"notificationTitle\"\n      }, item.notificationTitle), React.createElement(\"div\", {\n        className: \"notificationIcons\"\n      }, React.createElement(react_3.TooltipHost, {\n        content: \"Open Notification\",\n        id: 'openNotification',\n        calloutProps: calloutProps,\n        styles: hostStyles\n      }, React.createElement(react_2.IconButton, {\n        iconProps: OpenIcon,\n        \"aria-label\": \"Open Notification\",\n        onClick: function onClick() {\n          return _this.props.openRecord(item.notificationId);\n        }\n      })), React.createElement(react_3.TooltipHost, {\n        content: \"Resend Notification\",\n        id: 'resendNotification',\n        calloutProps: calloutProps,\n        styles: hostStyles\n      }, React.createElement(react_2.IconButton, {\n        iconProps: SendIcon,\n        \"aria-label\": \"Resend Notification\",\n        onClick: function onClick() {\n          return _this.props.resendNotifications(item.notificationId);\n        }\n      })), React.createElement(react_3.TooltipHost, {\n        content: \"Hide Notification\",\n        id: 'hideNotification',\n        calloutProps: calloutProps,\n        styles: hostStyles\n      }, React.createElement(react_2.IconButton, {\n        iconProps: HideIcon,\n        \"aria-label\": \"Hide Notification\",\n        onClick: function onClick() {\n          return _this.props.hideRecord(item.notificationId);\n        }\n      })))), React.createElement(\"div\", {\n        className: \"notificationBody\"\n      }, item.notificationBody), React.createElement(\"div\", {\n        className: \"notificationDate\"\n      }, item.notificationDate)));\n    }));\n  };\n  return NotificationListControl;\n}(React.Component);\nexports.NotificationListControl = NotificationListControl;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./NotificationList/NotificationList.tsx?");

/***/ }),

/***/ "./NotificationList/index.ts":
/*!***********************************!*\
  !*** ./NotificationList/index.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.NotificationList = void 0;\nvar NotificationList_1 = __webpack_require__(/*! ./NotificationList */ \"./NotificationList/NotificationList.tsx\");\nvar React = __webpack_require__(/*! react */ \"react\");\nvar NotificationList = /** @class */function () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function NotificationList() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   */\n  NotificationList.prototype.init = function (context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n    this._context = context;\n    // let dataSet = context.parameters.notificationDataSet;\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   * @returns ReactElement root react element for the control\r\n   */\n  NotificationList.prototype.updateView = function (context) {\n    var props = {\n      dataset: context.parameters.notificationDataSet,\n      publisherPrefix: context.parameters.publisherPrefix.raw,\n      loadMore: this.loadMoreRecords,\n      openRecord: this.openRecord,\n      hideRecord: this.deactivateRecord,\n      resendNotifications: this.resendRecordNotifications,\n      executeAction: this.executeAction\n    };\n    var iconProps = {\n      disabled: false,\n      checked: false\n    };\n    return React.createElement(NotificationList_1.NotificationListControl, props, iconProps);\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  NotificationList.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  NotificationList.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n  };\n  NotificationList.prototype.executeAction = function (actionType, id) {\n    alert(actionType);\n    alert(id);\n  };\n  NotificationList.prototype.openRecord = function (id) {\n    console.log(\"Open Record: \" + id);\n    var entityName = this._context.parameters.notificationDataSet.getTargetEntityType();\n    var entityFormOptions = {\n      entityName: entityName,\n      entityId: id\n    };\n    this._context.navigation.openForm(entityFormOptions);\n  };\n  NotificationList.prototype.loadMoreRecords = function () {\n    this._context.parameters.notificationDataSet.paging.loadNextPage();\n  };\n  NotificationList.prototype.deactivateRecord = function (id) {\n    console.log(\"Deactivate Record: \" + id);\n    var entityName = this._context.parameters.notificationDataSet.getTargetEntityType();\n    var data = {\n      \"statecode\": 1,\n      \"statuscode\": 2\n    };\n    this._context.webAPI.updateRecord(entityName, id, data).then(function success(result) {\n      console.log(id + \" hidden\");\n    }, function (error) {\n      console.log(error.message);\n    });\n  };\n  NotificationList.prototype.resendRecordNotifications = function (id) {\n    console.log(\"Resend Record: \" + id);\n    var entityName = this._context.parameters.notificationDataSet.getTargetEntityType();\n    var fieldName = this._context.parameters.publisherPrefix.raw + \"fieldName\";\n    var data = {\n      fieldName: 1\n    };\n    this._context.webAPI.updateRecord(entityName, id, data).then(function success(result) {\n      console.log(id + \" being resent\");\n    }, function (error) {\n      console.log(error.message);\n    });\n  };\n  return NotificationList;\n}();\nexports.NotificationList = NotificationList;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./NotificationList/index.ts?");

/***/ }),

/***/ "@fluentui/react":
/*!*************************************!*\
  !*** external "FluentUIReactv8290" ***!
  \*************************************/
/***/ ((module) => {

module.exports = FluentUIReactv8290;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/***/ ((module) => {

module.exports = React;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./NotificationList/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('MDT.VirtualControl.Core.NotificationList', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.NotificationList);
} else {
	var MDT = MDT || {};
	MDT.VirtualControl = MDT.VirtualControl || {};
	MDT.VirtualControl.Core = MDT.VirtualControl.Core || {};
	MDT.VirtualControl.Core.NotificationList = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.NotificationList;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}