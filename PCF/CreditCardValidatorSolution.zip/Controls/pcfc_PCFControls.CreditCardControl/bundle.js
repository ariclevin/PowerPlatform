/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./CreditCardControl/CreditCard.tsx":
/*!******************************************!*\
  !*** ./CreditCardControl/CreditCard.tsx ***!
  \******************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

eval("\n\nvar __extends = this && this.__extends || function () {\n  var _extendStatics = function extendStatics(d, b) {\n    _extendStatics = Object.setPrototypeOf || {\n      __proto__: []\n    } instanceof Array && function (d, b) {\n      d.__proto__ = b;\n    } || function (d, b) {\n      for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];\n    };\n    return _extendStatics(d, b);\n  };\n  return function (d, b) {\n    if (typeof b !== \"function\" && b !== null) throw new TypeError(\"Class extends value \" + String(b) + \" is not a constructor or null\");\n    _extendStatics(d, b);\n    function __() {\n      this.constructor = d;\n    }\n    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());\n  };\n}();\nvar __assign = this && this.__assign || function () {\n  __assign = Object.assign || function (t) {\n    for (var s, i = 1, n = arguments.length; i < n; i++) {\n      s = arguments[i];\n      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];\n    }\n    return t;\n  };\n  return __assign.apply(this, arguments);\n};\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.CreditCard = void 0;\nvar React = __webpack_require__(/*! react */ \"react\");\nvar Label_1 = __webpack_require__(/*! @fluentui/react/lib/Label */ \"@fluentui/react/lib/Label\");\nvar TextField_1 = __webpack_require__(/*! @fluentui/react/lib/TextField */ \"@fluentui/react/lib/Label\");\nvar Image_1 = __webpack_require__(/*! @fluentui/react/lib/Image */ \"@fluentui/react/lib/Label\");\nvar Stack_1 = __webpack_require__(/*! @fluentui/react/lib/Stack */ \"@fluentui/react/lib/Label\");\nvar horizontalGapStackTokens = {\n  childrenGap: 10,\n  padding: 10\n};\nvar imageProps = {\n  imageFit: Image_1.ImageFit.none,\n  width: 38,\n  height: 24\n};\nvar textFieldProps = {\n  // label: 'Credit Card Number',\n  defaultValue: \"0000000000000000\"\n};\n// id: useId(\"txtCreditCardNumber\")\nvar creditCardImage = 'https://bgx.blob.core.windows.net/shared/imgs/ico/redwarning.png';\nvar getOnChange = function getOnChange(event, newValue) {\n  getCreditCardImage(newValue);\n};\nvar getCreditCardImage = function getCreditCardImage(newValue) {\n  if (newValue !== undefined) {\n    var creditCardNumberText = newValue;\n    if (creditCardNumberText.length >= 13 && creditCardNumberText.length <= 16) {\n      if (creditCardNumberText.length == 15 && (creditCardNumberText.substring(0, 2) === \"34\" || creditCardNumberText.substring(0, 2) === \"37\")) creditCardImage = \"https://bgx.blob.core.windows.net/shared/imgs/ico/amex24.png\";else if (creditCardNumberText.substring(0, 1) === \"4\" && (creditCardNumberText.length == 13 || creditCardNumberText.length == 16)) creditCardImage = \"https://bgx.blob.core.windows.net/shared/imgs/ico/visa24.png\";else if (creditCardNumberText.substring(0, 4) === \"6011\" && creditCardNumberText.length == 16) creditCardImage = \"https://bgx.blob.core.windows.net/shared/imgs/ico/disc24.png\";else if (parseInt(creditCardNumberText.substring(0, 2)) > 50 && parseInt(creditCardNumberText.substring(0, 2)) < 56 && creditCardNumberText.length == 16) creditCardImage = \"https://bgx.blob.core.windows.net/shared/imgs/ico/mc24.png\";else creditCardImage = \"https://bgx.blob.core.windows.net/shared/imgs/ico/redwarning.png\";\n    } else {\n      creditCardImage = \"https://bgx.blob.core.windows.net/shared/imgs/ico/redwarning.png\";\n    }\n  }\n  imageProps.src = creditCardImage;\n  // console.log(creditCardImage);  \n};\nvar getErrorMessage = function getErrorMessage(creditCardNumber) {\n  var errorMessage = '';\n  if (creditCardNumber.length >= 13) {\n    switch (creditCardNumber.length) {\n      case 13:\n        if (creditCardNumber.substring(0, 1) !== \"4\") {\n          errorMessage = \"Visa credit card numbers of 13 digits begin with the number 4\";\n        }\n        break;\n      case 15:\n        if (creditCardNumber.substring(0, 2) !== \"34\" && creditCardNumber.substring(0, 2) !== \"37\") {\n          errorMessage = \"AMEX credit card numbers must begin with 34 or 37\";\n        }\n        break;\n      case 16:\n        if (creditCardNumber.substring(0, 1) !== \"4\" && creditCardNumber.substring(0, 1) !== \"5\" && creditCardNumber.substring(0, 4) !== \"6011\") {\n          errorMessage = \"The credit card number you entered is not valid\";\n        }\n        break;\n    }\n  } else {\n    errorMessage = 'Credit Card Numbers must be at least 13 digits';\n  }\n  return errorMessage;\n};\nvar CreditCard = /** @class */function (_super) {\n  __extends(CreditCard, _super);\n  function CreditCard() {\n    return _super !== null && _super.apply(this, arguments) || this;\n  }\n  CreditCard.prototype.renderLabel = function () {\n    return React.createElement(Label_1.Label, null, \"Credit Card Number\");\n  };\n  CreditCard.prototype.renderTextField = function () {\n    return React.createElement(TextField_1.TextField, __assign({}, textFieldProps, {\n      onChange: getOnChange,\n      onGetErrorMessage: getErrorMessage\n    }));\n  };\n  CreditCard.prototype.renderImage = function () {\n    // console.log(textFieldProps.value);\n    getCreditCardImage(textFieldProps.value);\n    return React.createElement(Image_1.Image, __assign({}, imageProps, {\n      src: creditCardImage,\n      alt: 'Credit Card Type'\n    }));\n  };\n  CreditCard.prototype.render = function () {\n    return React.createElement(Stack_1.Stack, {\n      horizontal: true,\n      disableShrink: true,\n      tokens: horizontalGapStackTokens\n    }, React.createElement(Stack_1.Stack.Item, null, this.renderLabel()), React.createElement(Stack_1.Stack.Item, {\n      grow: true,\n      disableShrink: true\n    }, this.renderTextField()), React.createElement(Stack_1.Stack.Item, null, this.renderImage()));\n  };\n  return CreditCard;\n}(React.Component);\nexports.CreditCard = CreditCard;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./CreditCardControl/CreditCard.tsx?");

/***/ }),

/***/ "./CreditCardControl/index.ts":
/*!************************************!*\
  !*** ./CreditCardControl/index.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.CreditCardControl = void 0;\nvar CreditCard_1 = __webpack_require__(/*! ./CreditCard */ \"./CreditCardControl/CreditCard.tsx\");\nvar React = __webpack_require__(/*! react */ \"react\");\nvar CreditCardControl = /** @class */function () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function CreditCardControl() {\n    var _this = this;\n    this.onChange = function (newValue) {\n      _this.currentValue = newValue;\n      console.log(newValue);\n      _this.notifyOutputChanged();\n    };\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   */\n  CreditCardControl.prototype.init = function (context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n    this._context = context;\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   * @returns ReactElement root react element for the control\r\n   */\n  CreditCardControl.prototype.updateView = function (context) {\n    var _a, _b;\n    var props = {\n      name: 'Credit Card Number Label',\n      ccNumber: this.currentValue,\n      imageUrl: this.getImageSource(),\n      onChange: this.onChange\n    };\n    var textFieldProps = {\n      label: 'Credit Card Number',\n      value: (_a = this._context.parameters.CreditCardNumber.raw) === null || _a === void 0 ? void 0 : _a.toString(),\n      defaultValue: (_b = this._context.parameters.CreditCardNumber.raw) === null || _b === void 0 ? void 0 : _b.toString(),\n      maxLength: 16\n    };\n    this.notifyOutputChanged();\n    return React.createElement(CreditCard_1.CreditCard, props, textFieldProps);\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  CreditCardControl.prototype.getOutputs = function () {\n    return {\n      CreditCardNumber: this.currentValue\n    };\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  CreditCardControl.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n  };\n  CreditCardControl.prototype.getImageSource = function () {\n    var _a;\n    var creditCardNumber = (_a = this._context.parameters.CreditCardNumber.raw) === null || _a === void 0 ? void 0 : _a.toString();\n    var imageSrc = '';\n    if (creditCardNumber != null && creditCardNumber.length >= 13 && creditCardNumber.length <= 16) {\n      if (creditCardNumber.length == 15 && (creditCardNumber.substring(0, 2) === \"34\" || creditCardNumber.substring(0, 2) === \"37\")) imageSrc = \"https://bgx.blob.core.windows.net/shared/imgs/ico/amex24.png\";else if (creditCardNumber.substring(0, 1) === \"4\" && (creditCardNumber.length == 13 || creditCardNumber.length == 16)) imageSrc = \"https://bgx.blob.core.windows.net/shared/imgs/ico/visa24.png\";else if (creditCardNumber.substring(0, 4) === \"6011\" && creditCardNumber.length == 16) imageSrc = \"https://bgx.blob.core.windows.net/shared/imgs/ico/disc24.png\";else if (parseInt(creditCardNumber.substring(0, 2)) > 50 && parseInt(creditCardNumber.substring(0, 2)) < 56 && creditCardNumber.length == 16) imageSrc = \"https://bgx.blob.core.windows.net/shared/imgs/ico/mc24.png\";else imageSrc = \"https://bgx.blob.core.windows.net/shared/imgs/ico/redwarning.png\";\n    } else {\n      imageSrc = \"\";\n    }\n    return imageSrc;\n  };\n  return CreditCardControl;\n}();\nexports.CreditCardControl = CreditCardControl;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./CreditCardControl/index.ts?");

/***/ }),

/***/ "@fluentui/react/lib/Label":
/*!*************************************!*\
  !*** external "FluentUIReactv8290" ***!
  \*************************************/
/***/ ((module) => {

module.exports = FluentUIReactv8290;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/***/ ((module) => {

module.exports = React;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./CreditCardControl/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('PCFControls.CreditCardControl', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.CreditCardControl);
} else {
	var PCFControls = PCFControls || {};
	PCFControls.CreditCardControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.CreditCardControl;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}