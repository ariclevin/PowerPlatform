/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./ACtionButton/ActionButton.tsx":
/*!***************************************!*\
  !*** ./ACtionButton/ActionButton.tsx ***!
  \***************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

eval("\n\nvar __extends = this && this.__extends || function () {\n  var _extendStatics = function extendStatics(d, b) {\n    _extendStatics = Object.setPrototypeOf || {\n      __proto__: []\n    } instanceof Array && function (d, b) {\n      d.__proto__ = b;\n    } || function (d, b) {\n      for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];\n    };\n    return _extendStatics(d, b);\n  };\n  return function (d, b) {\n    if (typeof b !== \"function\" && b !== null) throw new TypeError(\"Class extends value \" + String(b) + \" is not a constructor or null\");\n    _extendStatics(d, b);\n    function __() {\n      this.constructor = d;\n    }\n    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());\n  };\n}();\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.ActionButtonControl = void 0;\nvar React = __webpack_require__(/*! react */ \"react\");\nvar react_1 = __webpack_require__(/*! @fluentui/react */ \"@fluentui/react\");\nvar ActionButtonControl = /** @class */function (_super) {\n  __extends(ActionButtonControl, _super);\n  function ActionButtonControl() {\n    return _super !== null && _super.apply(this, arguments) || this;\n  }\n  ActionButtonControl.prototype.render = function () {\n    var actionButtonIcon = {\n      iconName: this.props.buttonIcon\n    };\n    switch (this.props.buttonType) {\n      case \"Default\":\n        if (this.props.buttonStyle == \"Standard\") {\n          return React.createElement(\"div\", null, React.createElement(react_1.DefaultButton, {\n            iconProps: actionButtonIcon,\n            text: this.props.displayName,\n            onClick: this.props.onChange,\n            disabled: this.props.buttonStatus\n          }));\n        } else {\n          return React.createElement(\"div\", null, React.createElement(react_1.PrimaryButton, {\n            iconProps: actionButtonIcon,\n            text: this.props.displayName,\n            onClick: this.props.onChange,\n            disabled: this.props.buttonStatus\n          }));\n        }\n      case \"Compound\":\n        if (this.props.buttonStyle == \"Standard\") {\n          return React.createElement(\"div\", null, React.createElement(react_1.CompoundButton, {\n            secondaryText: this.props.secondaryText,\n            onClick: this.props.onChange,\n            disabled: this.props.buttonStatus\n          }, this.props.displayName));\n        } else {\n          return React.createElement(\"div\", null, React.createElement(react_1.CompoundButton, {\n            primary: true,\n            secondaryText: this.props.secondaryText,\n            onClick: this.props.onChange,\n            disabled: this.props.buttonStatus\n          }, this.props.displayName));\n        }\n      default:\n        if (this.props.buttonStyle == \"Standard\") {\n          return React.createElement(\"div\", null, React.createElement(react_1.DefaultButton, {\n            iconProps: actionButtonIcon,\n            text: this.props.displayName,\n            onClick: this.props.onChange,\n            disabled: this.props.buttonStatus\n          }));\n        } else {\n          return React.createElement(\"div\", null, React.createElement(react_1.PrimaryButton, {\n            iconProps: actionButtonIcon,\n            text: this.props.displayName,\n            onClick: this.props.onChange,\n            disabled: this.props.buttonStatus\n          }));\n        }\n    }\n  };\n  return ActionButtonControl;\n}(React.Component);\nexports.ActionButtonControl = ActionButtonControl;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ACtionButton/ActionButton.tsx?");

/***/ }),

/***/ "./ACtionButton/index.ts":
/*!*******************************!*\
  !*** ./ACtionButton/index.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.ActionButton = void 0;\nvar ActionButton_1 = __webpack_require__(/*! ./ActionButton */ \"./ACtionButton/ActionButton.tsx\");\nvar React = __webpack_require__(/*! react */ \"react\");\nvar ActionButton = /** @class */function () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function ActionButton() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   */\n  ActionButton.prototype.init = function (context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n    this._context = context;\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   * @returns ReactElement root react element for the control\r\n   */\n  ActionButton.prototype.updateView = function (context) {\n    var _a, _b, _c, _d, _e;\n    var props = {\n      displayName: (_a = context.parameters.buttonText.raw) === null || _a === void 0 ? void 0 : _a.toString(),\n      secondaryText: (_b = context.parameters.secondaryText.raw) === null || _b === void 0 ? void 0 : _b.toString(),\n      buttonType: (_c = context.parameters.buttonType.raw) === null || _c === void 0 ? void 0 : _c.toString(),\n      buttonStyle: (_d = context.parameters.buttonStyle.raw) === null || _d === void 0 ? void 0 : _d.toString(),\n      buttonIcon: (_e = context.parameters.buttonIcon.raw) === null || _e === void 0 ? void 0 : _e.toString(),\n      onChange: this.onButtonClick.bind(this),\n      buttonStatus: context.parameters.buttonStatus.raw === null ? true : context.parameters.buttonStatus.raw\n    };\n    return React.createElement(ActionButton_1.ActionButtonControl, props);\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  ActionButton.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  ActionButton.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n  };\n  ActionButton.prototype.onButtonClick = function () {\n    this.notifyOutputChanged();\n  };\n  return ActionButton;\n}();\nexports.ActionButton = ActionButton;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ACtionButton/index.ts?");

/***/ }),

/***/ "@fluentui/react":
/*!*************************************!*\
  !*** external "FluentUIReactv8290" ***!
  \*************************************/
/***/ ((module) => {

module.exports = FluentUIReactv8290;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/***/ ((module) => {

module.exports = React;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./ACtionButton/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('MDT.VirtualControl.Core.ActionButton', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ActionButton);
} else {
	var MDT = MDT || {};
	MDT.VirtualControl = MDT.VirtualControl || {};
	MDT.VirtualControl.Core = MDT.VirtualControl.Core || {};
	MDT.VirtualControl.Core.ActionButton = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ActionButton;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}